@echo off
echo =========================================
echo    CHAKKON PRO - PRINTER AGENTI
echo =========================================
echo.
echo Dastur ishga tushirilmoqda...
echo Agar node.js o'rnatilmagan bo'lsa, xato berishi mumkin!
echo.
node agent.js
pause
